<?php
/**
 *	Kalium WordPress Theme
 *	
 *	Laborator.co
 *	www.laborator.co 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Kalium_LayerSlider {
	
	/**
	 * Required plugin/s for this class
	 */
	public static $plugins = array( 'LayerSlider/layerslider.php' );
	
	/**
	 * Class instructor, define necessary actions
	 */
	public function __construct() {
	}
}