<?php

$fix = array(
	array(
		'behaviour',
		'function' => '__fix_responsive',
	),
	array(
		'preset',
		'function' => '__fix_responsive_preset',
	),
	array(
		'resolution',
		'wc_settings_prdctfltr_mobile_resolution',
	),
);