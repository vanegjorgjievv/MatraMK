<?php

$fix = array(
	array(
		'enable',
		'wc_settings_prdctfltr_adoptive',
	),
	array(
		'active_on',
		'wc_settings_prdctfltr_adoptive_mode',
	),
	array(
		'depend_on',
		'wc_settings_prdctfltr_adoptive_depend',
	),
	array(
		'term_counts',
		'wc_settings_prdctfltr_show_counts_mode',
	),
	array(
		'reorder_selected',
		'wc_settings_prdctfltr_adoptive_reorder',
	),
);